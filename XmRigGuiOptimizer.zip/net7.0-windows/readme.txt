XMRig Ranch Monitor - Professional Mining Dashboard
📖 Overview
XMRig Ranch Monitor is a professional Windows application that provides a beautiful, user-friendly interface for managing and monitoring your XMRig cryptocurrency mining operations. It transforms the command-line XMRig miner into a visual dashboard with real-time statistics, performance monitoring, and easy configuration.

🚀 What It Does
Core Features:
Real-time Monitoring: Live gauges showing CPU usage, RAM usage, hashrate, temperature, and power consumption

Professional Dashboard: Beautiful tachometer and linear gauges with smooth animations

Smart Configuration: Easy settings management for pools, wallets, and performance tuning

Auto-Tuning: Automatically optimizes settings based on your system specifications

Temperature Monitoring: Real CPU temperature reading with color-coded alerts

Power Estimation: Calculates and displays estimated power consumption

Dynamic Scaling: Automatically adjusts display scales for optimal readability

One-Click Mining: Simple start/stop controls with visual status indicators

Technical Capabilities:
Multiple Pool Support: Configure any Monero mining pool

Performance Controls: Adjust CPU usage, priority, and advanced XMRig settings

Hardware Optimization: Auto-detects system specs and suggests optimal configurations

Configurable Dev Fee: Support development with adjustable donation levels (0-5%)

Advanced Features: Huge Pages, Hardware AES, TLS, NUMA support, and more

⚙️ How It Works
Architecture:
Frontend: Windows Forms application with custom-drawn gauges and real-time updates

Backend: Manages XMRig process and system monitoring

Configuration: JSON-based settings with automatic saving/loading

Monitoring: System performance tracking through WMI and simulated sensors

System Integration:
XMRig Integration: Launches and manages the official XMRig miner

System Detection: Automatically detects CPU cores, threads, and memory

Temperature Reading: Uses WMI to read actual CPU temperatures when available

Performance Smoothing: Applies exponential moving averages for stable readings

🎮 How to Operate
Initial Setup:
Prerequisites:

Windows 10/11

.NET 6.0 Runtime

XMRig executable (xmrig.exe) in the same folder

First Launch:

The application starts with default MoneroOcean pool settings

System specs are automatically detected

Default configuration is created in config.json

Basic Operation:
Starting Mining:
Click the "START MINING" button (green)

Watch real-time statistics populate:

CPU Usage gauge (0-100%)

RAM Usage gauge (0-100%)

Hashrate gauge (auto-scaling)

Temperature gauge with color zones

Power consumption display

Stopping Mining:
Click the "STOP MINING" button (red)

All mining activity ceases immediately

Statistics reset to baseline

Configuration:
Accessing Settings:
Click the "SETTINGS" button

Configure in the settings dialog:

Pool Settings:
Pool URL: Your mining pool address (e.g., gulf.moneroocean.stream:10128)

Wallet Address: Your Monero wallet address

Worker Name: Identifier for this mining rig

Performance Settings:
Max CPU Usage: Slider from 10-100% (recommended: 75-85%)

CPU Priority: Dropdown from Idle to Realtime

Developer Fee:
Select donation level: 0%, 1%, 2%, or 5%

Supports ongoing development

Advanced Settings:
Huge Pages: Improves performance (recommended: Enabled)

Hardware AES: Uses CPU AES instructions (recommended: Enabled)

TLS: Encrypted connection to pool (if supported)

Auto-Tuning:
Click "AUTO TUNE" in settings

System analyzes your hardware:

CPU core count and capabilities

Total system memory

Supported features

Applies optimal settings automatically

Confirms changes with summary

Monitoring Dashboard:
Real-time Gauges:
CPU Gauge: Current processor utilization

RAM Gauge: Memory usage percentage

Hashrate Gauge: Mining performance with auto-scaling

Temperature Gauge: CPU temperature with color alerts:

Green: <50°C (Cool)

Yellow: 50-70°C (Warm)

Orange: 70-85°C (Hot)

Red: >85°C (Critical)

Power Gauge: Estimated power consumption

Statistics Panel:
Current Hashrate: Live mining speed

Highest Hashrate: Peak performance recorded

Average Hashrate: Smoothed average performance

Share Statistics: Total, accepted, and rejected shares

Status Indicators:
READY: Application loaded, ready to mine

MINING: Actively mining (green)

STOPPED: Mining stopped (red)

🔧 Advanced Features
Dynamic Hashrate Scaling:
Automatically adjusts gauge scale from H/s to MH/s

Ensures optimal gauge visibility regardless of performance

Scale indicators show current measurement range

Smart Temperature Monitoring:
Attempts real temperature reading via WMI

Falls back to simulated temperature based on CPU usage

Color-coded zones for quick status assessment

Configuration Management:
Settings automatically save to config.json

Changes apply immediately when mining restarts

Backup your config file for easy migration

🛠️ Troubleshooting
Common Issues:
XMRig Not Found:

Ensure xmrig.exe is in the same directory as the application

Download latest XMRig from official sources

Temperature Reading Unavailable:

Some systems don't support WMI temperature reading

Application uses accurate simulation as fallback

High CPU Usage:

Reduce Max CPU Usage in settings

Lower CPU Priority if system becomes unresponsive

Pool Connection Issues:

Verify pool URL and port

Check internet connection

Ensure wallet address is correct

Performance Tips:
Optimal Settings:

Use Auto-Tune for best results

Enable Huge Pages for performance boost

Set appropriate CPU usage for your cooling

Monitoring:

Watch temperature gauges during extended mining

Adjust CPU usage if temperatures exceed 85°C

Monitor share acceptance rate for pool health

System Stability:

Start with 75% CPU usage and increase gradually

Use "Normal" priority for background mining

"Realtime" priority for maximum performance (may affect system responsiveness)

📁 File Structure
text
Xmrig_Ranch_Launcher/
├── XmrigLauncher.exe          # Main application
├── xmrig.exe                  # Mining engine (user provided)
├── config.json               # Settings and configuration
├── README.md                 # This documentation
└── (Runtime dependencies)
⚠️ Disclaimer
This software interfaces with XMRig but is not affiliated with the XMRig project

Cryptocurrency mining may impact system performance and hardware lifespan

Monitor temperatures and system stability during operation

Ensure compliance with local laws and electricity costs

Mining profitability varies with cryptocurrency markets

🆕 Version Information
Current Version: 1.0
Compatibility: Windows 10/11, .NET 6.0
XMRig Version: Compatible with XMRig 6.18.0+

Happy Mining! 🚀⛏️

For support issues, check the troubleshooting section above or ensure your system meets the prerequisites. The application is designed to be intuitive, but don't hesitate to reference this guide for optimal configuration.